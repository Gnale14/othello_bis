package Modele;

public class Grille {
    private int[][] plateau;
    private int nbLigne;
    private int nbColonne;

    public Grille() {
        plateau= new int [8][8];
        for (int i = 0;i<8;i++){
            for(int j=0; j<8;j++){
                plateau[i][j] = 0;
            }
        }
        plateau[3][3]=plateau[4][4]=1;
        plateau[3][4]=plateau[4][3]=2;
        nbLigne =8;
        nbColonne = 8;
    }


    public Grille(int ligne, int colonne) {
        plateau= new int [ligne][colonne];
        for (int i = 0;i<ligne;i++){
            for(int j=0; j<colonne;j++){
                plateau[i][j] = 0;
            }
        }
        plateau[ligne/2][(colonne/2)-1]=plateau[ligne/2][(colonne/2)-1]=1;
        plateau[(ligne/2)-1][colonne/2]=plateau[ligne/2][colonne/2]=2;
        nbLigne = ligne;
        nbColonne = colonne;
    }

    @Override
    //affichage grille
    public String toString() {
        System.out.println (" ");
        System.out.println("-------REVERSI-------");
        System.out.println (" ");
        String res = "  |A|B|C|D|E|F|G|H|\n";

        for (int i = 0;i<nbLigne;i++){
            res+= i+1 + " |";
            for(int j=0; j<nbColonne;j++){
                switch (plateau[i][j]){
                    case 0:
                        res += "\uD83D\uDFE9";
                        break;
                    case 1:
                        res +=  "\u26AA";
                        break;
                    case 2: 
                        res +=  "\u26AB";
                        break;
                }
            }
            res+="\n";
        }
        return res;
    }

    public boolean estFinie() {
        for (int i = 1;i<=nbLigne;i++) {
            for (int j = 1; j <= nbColonne; j++) {
                if (plateau[i][j] == 0){
                    return false;
                }
            }
        }
        return true;
    }

    public int gererCoup(int numeroLigne, int numeroColonne, int numJoueur)  {
        int validite ;
        validite = deplacementValideV2(numeroLigne,numeroColonne,numJoueur);
        if (validite == 1){
            return 1;
        }
        return 0;
    }

    int deplacementValideV2(int numLigne, int numColone,int numJoueurActif){
        char icone;
        if(numJoueurActif==1){
            icone = 1;
        }
        else {
            icone = 2;
        }
        if ( plateau[numLigne][numColone] != 0 ){
            return 0;
        }

        plateau[numLigne][numColone] = icone;
        return 1;
        
        
    }

    /* int deplacementValide (int numeroLigne,int numeroColonne,int deltaLigne,int deltaColonne, int numJoueurActif, int action) {
        int nDT = 1;
        int nDL = 0;
        int nDC = 0;
        char icone ,autreIcone ;
        if(numJoueurActif==1){
            icone = 1;
            autreIcone = 2;
        }
        else {
            icone = 2;
            autreIcone = 1;
        }
        if (plateau[numeroLigne][numeroColonne]==0){
            while (numeroLigne+2*deltaLigne + nDL >= 0 
                        && numeroLigne +2*deltaLigne + nDL <=7 
                        && numeroColonne + 2*deltaColonne + nDC >=0 
                        && numeroColonne + 2*deltaColonne + nDC <= 7 
                        && plateau[numeroLigne+deltaLigne+nDL][numeroColonne+deltaColonne+nDC]==autreIcone){
                nDL = deltaLigne + nDL ;
                nDC = deltaColonne + nDC ;
                nDT = nDT + 1;
                if (plateau [numeroLigne+deltaLigne+nDL][numeroColonne+deltaColonne+nDC]== icone ){
                    if (action == 2){
                        for (int k = 0 ;k <=nDT ; k++){
                            plateau [numeroLigne+deltaLigne*k][numeroColonne+deltaColonne*k]= icone ;
                        }
                        return 1 ;
                    }
                }
            }

        }
        return 0;
    }
 */

}
