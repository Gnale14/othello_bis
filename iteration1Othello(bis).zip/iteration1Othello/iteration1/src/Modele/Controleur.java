package Modele;

import Vue.Ihm;

public class Controleur {
    private Ihm ihm;
    private Joueur j1;
    private Joueur j2;
    private Joueur joueurActif;
    private Grille grille;

    public Grille getGrille() {
        return grille;
    }

    public Controleur(Ihm ihm) {
        this.ihm = ihm;
        ihm.setControleur(this);
        j1 = new Joueur(1);
        j2 = new Joueur(2);
        ihm.demanderJoueur(1);
        ihm.demanderJoueur(2);
        grille = new Grille(); // Changer la taille de la grille
        joueurActif = j1;
    }

    public Joueur getJ1() {
        return j1;
    }

    public Joueur getJ2() {
        return j2;
    }

    public Joueur getJoueurActif() {
        return joueurActif;
    }

    public void commencerJeu(){
        boolean jouer = true;
        while (jouer){
            lancerPartie();
            gererVainqueur();
            jouer = ihm.demanderRejouer();
        }
        ihm.finDuJeu(j1.getNom(), j1.getNbPartieGagnee(), j2.getNom(), j2.getNbPartieGagnee());
    }


    public void lancerPartie() {
        ihm.afficherEtat(grille.toString());
        while(!grille.estFinie()){


            ihm.demanderCoup(joueurActif.getNom());
            ihm.afficherEtat(grille.toString());
            changementDeJoueur();
            ihm.afficherDemanderCoup(joueurActif.getNom());
        }
    }

    private void gererVainqueur() {

    }

    public void changementDeJoueur() {
        if (joueurActif.equals(j1)){
            joueurActif = j2;
        }else{
            joueurActif = j1;
        }
    }

    public void gererCoup(int numeroLigne, int numeroColonne) {
        if (grille.gererCoup(numeroLigne, numeroColonne, joueurActif.getNumJoueur()) == 1){
            ihm.afficherEtat(getGrille().toString());
            changementDeJoueur();
            ihm.afficherDemanderCoup(joueurActif.getNom());
            ihm.demanderCoup(joueurActif.getNom());
        }
    }
}
