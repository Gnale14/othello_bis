package Vue;

import Modele.Controleur;

import java.util.Scanner;

public class Ihm {
    Controleur controleur;
    Scanner sc;


    public void setControleur(Controleur controleur) {
        this.controleur = controleur;
        sc = new Scanner(System.in);
    }

    public void demanderJoueur(int num){
        System.out.println("Saisir le nom du joueur "+ num);
        if (sc.hasNext()){
            String nom = sc.nextLine();
            if (num==1){
                controleur.getJ1().setNom(nom);
            }else{
                controleur.getJ2().setNom(nom);
            }
        }
    }

    public void afficherEtat(String grille) {
        System.out.println(grille);
    }

    public void afficherDemanderCoup(String nom) {
        System.out.println(nom + " à vous de jouer saissisez une ligne une ligne entre 1 et 8 suivit d'une lettre entr A et H ou P pour passer votre coup");
    }

    public void demanderCoup(String nom) {
        String[] inputs = new String[2];
        while (true){
            if (sc.hasNext()){
                String ligne = sc.nextLine();

                if (ligne.toLowerCase().equals("P".toLowerCase())){
                    controleur.changementDeJoueur();
                    afficherDemanderCoup(controleur.getJoueurActif().getNom());
                    demanderCoup(controleur.getJoueurActif().getNom());
                }else{
                    inputs = ligne.split(" ");
                    if (inputs.length < 2){
                        System.out.println("Erreur veuillez entrer 2 valeur");
                        afficherDemanderCoup(nom);
                    }
                }
            }
            break;
        }
        
        int numeroLigne = Integer.parseInt(inputs[0]);
        char lettre = inputs[1].charAt(0);
        int valeurLettre = lettre - 'A';
        
        controleur.gererCoup(numeroLigne-1, valeurLettre);
    }

    public boolean demanderRejouer() {
        while (true){
            System.out.println("Voulez vous rejouer ? Y/N");
            if (sc.hasNext()){
                String ligne = sc.nextLine();
                if (ligne.equals("Y")){
                    return true;
                }else if (ligne.equals("N")){
                    return false;
                }else{
                    System.out.println("Erreur");
                }
            }
        }
    }

    public void finDuJeu(String j1Nom, int j1NbPartieGagnee, String j2Nom, int j2NbPartieGagnee) {
        if (j1NbPartieGagnee > j2NbPartieGagnee){
            System.out.println("Le joueur "+ j1Nom + "à gagné");
        }else if (j1NbPartieGagnee < j2NbPartieGagnee) {
            System.out.println("Le joueru "+ j2Nom + "à gangé");
        }else{
            System.out.println("Egalité");
        }
    }
}
